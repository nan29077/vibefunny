import { NextRequest, NextResponse } from "next/server";
import { getDb, saveDb } from "@/lib/db";
import { nanoid } from "nanoid";

export async function POST(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  const db = getDb();
  const body = await req.json();
  const { creator_id, participation_type = "deploy" } = body as {
    creator_id: string;
    participation_type?: "deploy" | "video_production";
  };

  if (!creator_id) {
    return NextResponse.json({ error: "creator_id 필요" }, { status: 400 });
  }

  // 같은 campaign_id + creator_id + participation_type 조합 중복 체크
  const existing = (db.campaign_participations ?? []).find(
    (p) =>
      p.campaign_id === params.id &&
      p.creator_id === creator_id &&
      (p.participation_type ?? "deploy") === participation_type
  );
  if (existing) {
    return NextResponse.json({ error: "이미 해당 유형으로 참여중입니다" }, { status: 400 });
  }

  // 캠페인 존재 여부 확인
  const campaign = db.ad_campaigns.find((c) => c.id === params.id);
  if (!campaign) {
    return NextResponse.json({ error: "캠페인을 찾을 수 없습니다" }, { status: 404 });
  }

  // 참여 인원 제한 체크 (유형 구분 없이 전체 합산)
  if (campaign.participation_limit) {
    const currentCount = (db.campaign_participations ?? []).filter(
      (p) => p.campaign_id === params.id
    ).length;
    if (currentCount >= campaign.participation_limit) {
      return NextResponse.json({ error: "참여 인원이 마감되었습니다" }, { status: 400 });
    }
  }

  const participation = {
    id: nanoid(),
    campaign_id: params.id,
    creator_id: creator_id,
    status: "applied" as const,
    participation_type: participation_type as "deploy" | "video_production",
    applied_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  };

  if (!db.campaign_participations) db.campaign_participations = [];
  db.campaign_participations.push(participation);
  saveDb(db);

  return NextResponse.json(participation);
}
