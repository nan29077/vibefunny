import { requireRole } from "@/lib/auth";
import { getDb } from "@/lib/db";
import { Card, PageHeader, Field, Input, Select, Table, Th, Td, StatusBadge, EmptyState } from "@/components/ui";
import { SubmitButton } from "@/components/form";
import { SOCIAL_PLATFORM_LABELS, SOCIAL_PLATFORM_COLORS, ALL_SOCIAL_PLATFORMS } from "@/lib/schema";
import { addSocialAction, deleteSocialAction } from "@/lib/actions/social-actions";

export default function CreatorSocialPage() {
  const user = requireRole("creator");
  const db = getDb();
  const accounts = db.social_accounts.filter((s) => s.creator_id === user.id);

  return (
    <div className="space-y-6">
      <PageHeader title="SNS 계정 관리" description="YouTube, Instagram, TikTok, Facebook 채널을 등록하세요." />

      <Card className="border-brand-yellow/40 bg-brand-yellow/5">
        <p className="text-sm text-gray-700">
          🔒 보안을 위해 <b>SNS 비밀번호는 절대 수집하지 않습니다.</b> 채널 URL, 계정명, 플랫폼, 인증 상태만 저장됩니다.
        </p>
      </Card>

      <Card>
        <h2 className="mb-3 text-base font-bold">계정 추가</h2>
        <form action={addSocialAction} className="grid items-end gap-3 sm:grid-cols-4">
          <Field label="플랫폼">
            <Select name="platform" defaultValue="youtube">
              {ALL_SOCIAL_PLATFORMS.map((p) => (
                <option key={p} value={p}>{SOCIAL_PLATFORM_LABELS[p]}</option>
              ))}
            </Select>
          </Field>
          <Field label="계정명">
            <Input name="account_name" placeholder="@channel" required />
          </Field>
          <Field label="채널 URL">
            <Input name="channel_url" placeholder="https://..." required />
          </Field>
          <Field label="팔로워 수">
            <Input type="number" name="follower_count" min={0} defaultValue={0} />
          </Field>
          <SubmitButton size="sm">추가</SubmitButton>
        </form>
      </Card>

      {accounts.length === 0 ? (
        <EmptyState title="등록된 SNS 계정이 없습니다" />
      ) : (
        <Table>
          <thead>
            <tr><Th>플랫폼</Th><Th>계정명</Th><Th>채널</Th><Th>팔로워</Th><Th>인증</Th><Th></Th></tr>
          </thead>
          <tbody>
            {accounts.map((s) => (
              <tr key={s.id}>
                <Td>
                  <span
                    className="inline-flex items-center rounded-full px-2 py-0.5 text-xs font-bold"
                    style={{
                      color: SOCIAL_PLATFORM_COLORS[s.platform].color,
                      background: SOCIAL_PLATFORM_COLORS[s.platform].bg,
                    }}
                  >
                    {SOCIAL_PLATFORM_LABELS[s.platform]}
                  </span>
                </Td>
                <Td>{s.account_name}</Td>
                <Td><a href={s.channel_url} target="_blank" rel="noreferrer" className="text-brand-purple underline">바로가기</a></Td>
                <Td>{s.follower_count.toLocaleString("ko-KR")}</Td>
                <Td><StatusBadge status={s.verified_status} /></Td>
                <Td>
                  <form action={deleteSocialAction}>
                    <input type="hidden" name="id" value={s.id} />
                    <SubmitButton size="sm" variant="danger">삭제</SubmitButton>
                  </form>
                </Td>
              </tr>
            ))}
          </tbody>
        </Table>
      )}
    </div>
  );
}
